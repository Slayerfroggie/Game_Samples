function love.conf(settings)
	settings.window.width = 800
	settings.window.height = 600
	settings.title = "Psycho Python"
end